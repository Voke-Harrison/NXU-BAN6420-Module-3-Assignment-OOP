# BAN6420 Module 2 Assignment: Salary Function
# Voke Harrison Edafejimue
# Learner ID - 143304

# An Insurance Company Policy Management System
# Payment Management Script
# Implement methods for payment processing, reminders, and penalties.

from policyholders1 import *
from Products1 import *
from datetime import date


class PolicyPayments(InsuranceCompany):
    def __init__(self):
        super().__init__()
        # Create an empty Dictionary
        self.payments_list = {}

    # New Policy payment entry
    def payment(self, policy_id, product_name, amount):
        if policy_id in self.policy_holders:
            pay_list = [date.today(), product_name, amount]
            self.payments_list[policy_id] = pay_list
            self.policy_holders[policy_id][2] = 'Active'
            print(f"Successful Policy Payment for Product: {product_name}")
            print(self.payments_list)
            return pay_list
        else:
            print(f"Policy ID: {policy_id} does not exist.")

    # Print out reminders for Policy Holders whose payments are due for less than or equal to 30 days
    def reminders(self):
        for policy_id in self.payments_list:
            today = date.today()
            if 30 <= (today - self.payments_list[policy_id][0]) <= 60:
                print(f"Dear {self.policy_holders[policy_id][0]}, Your Subscription has ended. Kindly make Payments")
                continue
            else:
                pass

    # Print out reminders for Policy Holders whose payments are due for more than 60 days and notifies that a
    # standard fee of $5 apply.
    def penalties(self):
        for policy_id in self.payments_list:
            today = date.today()
            if (today - self.payments_list[policy_id][0]) > 60:
                self.policy_holders[policy_id][2] = 'Suspended'
                print(
                    f"Dear {self.policy_holders[policy_id][0]}, Your Subscription has been suspended, "
                    f"as payments have not been made in 2 months.")
                print("To activate this subscription an additional payment of $5 will apply")
                continue


try:
    Operate = PolicyPayments()
    Operate.payment(102, 'Life Insurance', 300)
except TypeError:
    print("Invalid type entered")
except ValueError:
    print("Invalid Data Type entered")
except Exception as e:
    print(e)
else:
    pass
finally:
    pass
