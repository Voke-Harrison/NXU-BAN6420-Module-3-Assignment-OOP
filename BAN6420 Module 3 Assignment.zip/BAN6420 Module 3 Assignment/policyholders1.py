# BAN6420 Module 2 Assignment: Salary Function
# Voke Harrison Edafejimue
# Learner ID - 143304

# An Insurance Company Policy Management System
# Policyholder Management script
# Implement methods to register, suspend, and reactivate policyholders.


class InsuranceCompany:
    def __init__(self):
        # super().__init__()
        # Create an empty Dictionary
        self.policy_holders = {}

    # Register a new Policy Holder
    def register(self, policy_id, name, product_name='Not Subscribed', account_status='Inactive'):
        if policy_id in self.policy_holders:
            print("This Policy ID already exists.")
        else:
            new_list = [name, product_name, account_status]
            self.policy_holders[policy_id] = new_list
            print(new_list)
            print(self.policy_holders)
            print("New Policy Holder Registered Successfully")
            main_list = self.policy_holders
            return main_list

    # Suspend an existing Policy Holder's Account.
    def suspend(self, policy_id):
        if policy_id in self.policy_holders:
            self.policy_holders[policy_id][2] = 'Suspended'
            print(f"Policy Holder with ID: {policy_id} has been suspended.")
            main_list = self.policy_holders
            return main_list
        else:
            print("Policy Holder ID Does not Exist")

    # Reactivate an existing Policy Holder's account.
    def reactivate(self, policy_id):
        if policy_id in self.policy_holders:
            self.policy_holders[policy_id][2] = 'Active'
            print(self.policy_holders)
            print(f"Policy Holder with ID: {policy_id} is now Active")
            main_list = self.policy_holders
            return main_list
        else:
            print("Policy Holder ID Does not Exist")



try:
    New = InsuranceCompany()
    New.register(111, 'Jane Joe')
    New.register(222, 'Mike Jordan')
    New.register(333, 'Martin Lawrence')
    New.suspend(333)
    New.reactivate(222)
    New.register(101, 'Hilary Clinton', 'Life Insurance', 'Active')
    print(New.main_list)
    active_list = [New.register(102, 'Martin Lawrence', 'Life Insurance', 'Active')]

    # display active Policy Holder accounts only
    long = len(active_list)
    for i in range(1, long):
        if hasattr(active_list[3], 'Active'):
            print("=================================List of Active Accounts Only================")
            print(active_list)



except TypeError:
    print("Invalid type entered")
except ValueError:
    print("Invalid Data Type entered")
except Exception as e:
    print(e)
else:
    pass
finally:
    pass
