# NXU-BAN6420-Module-3-Assignment-OOP
# BAN6420 Module 2 Assignment: Salary Function
# Voke Harrison Edafejimue
# Learner ID - 143304

This Zipped file named BAN6420 Module 3 Assignment contains 3 files named:
* policyholders1
* Product1
* Payments1

Each of these files contains Class with multiple methods that handle distinct activities
* In policyholders1
    - Class - InsuranceCompany
      - Methods
         - register - can be used to register new Policy Holders
         - supend - can be used to suspend an existing account by changing its status to 'suspended'
         - reactivate - for reactivating an existing account
         - plus - additional code to print policy holders who have subscribed for a product and have the account status as 'Active'.
* In Products1
    - Class - PolicyProducts
      -Methods
        - create_product - for creating new products
        - update_product - can be used to update features of an existing product
        - remove_product - used to change the status of an existing product to 'suspended'.
     
* Payments1 
  - Class - PolicyPayments
    -Methods
      - payment - accepts the policy id of the Policy holder paying for a product and updates the account status of a registered policy holder to 'Active'
      - reminders - Print out reminders for Policy Holders whose payments are due for less than or equal to 30 days.
      - penalties - Print out reminders for Policy Holders whose payments are due for more than 60 days and notifies that a standard fee of $5 apply.
   
Thank you.