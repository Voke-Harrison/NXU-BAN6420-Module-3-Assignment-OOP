# BAN6420 Module 2 Assignment: Salary Function
# Voke Harrison Edafejimue
# Learner ID - 143304

# An Insurance Company Policy Management System
# Product Management Script
# Implement methods for creating, updating, and removing/suspending policy products.


class PolicyProducts:
    def __init__(self):
        # create an empty dictionary
        self.products = {}

    # Create New product
    def create_product(self, product_name, price, expiry_days=30, status='Active'):
        if product_name in self.products:
            print("Product already exists.")
        else:
            self.products[product_name] = [price, expiry_days, status]
            print(f"New Product - '{product_name}' Created Successfully.")
            print(self.products)

    # Update an existing product
    def update_product(self, product_name, new_price, new_expiry_days):
        if product_name in self.products:
            self.products[product_name][0] = new_price
            self.products[product_name][1] = new_expiry_days
            print(f"{product_name} has been updated - Price: {new_price} & Expiry: {new_expiry_days}")
            print(self.products)
        else:
            print("Product Name does not exist.")

    # Remove or suspend an existing product
    def remove_product(self, product_name):
        if product_name in self.products:
            self.products[product_name][2] = 'Suspended'
            print(f"Product - '{product_name}' Suspended Successfully.")
            print(self.products)


try:
    Create = PolicyProducts()
    Create.create_product('Life Insurance', 300)
    Create.create_product('Car Insurance', 150)
    Create.create_product('Health Insurance', 220)
    Create.update_product('Medical Insurance', 190, 30)
    Create.update_product('Health Insurance', 190, 30)
    Create.create_product('Renters Insurance', 20)
    Create.remove_product('Renters Insurance')

except TypeError:
    print("Invalid type entered")
except ValueError:
    print("Invalid Data Type entered")
except Exception as e:
    print(e)
else:
    pass
finally:
    pass
